"use strict";

import { vaciar } from "./Biblioteca.js";

window.onload = function () {
  var arr = document.getElementsByClassName("arrastrable");

  for (var i = 0; i < arr.length; i++) {
    arr[i].setAttribute("draggable", true);
  }

  var elementoArrastrado; // Elemento que va a ser arrastarado.

  document.addEventListener(
    "dragstart",
    (evento) => {
      elementoArrastrado = evento.target;
    },
    false
  );

  document.addEventListener(
    "dragover",
    (evento) => {
      evento.preventDefault();
    },
    false
  );

  document.addEventListener(
    "drop",
    (evento) => {
      evento.preventDefault();
      if (evento.target.className === "soltable") {
        evento.target.setAttribute("src", "./img/llena.jpg");
        evento.target.setAttribute("id", "llena");
        evento.target.appendChild(elementoArrastrado);
      }
    },
    false
  );

  const vaciarPapelera = document.getElementById("soltables");

  // Al hacer doble clic sobre la papelera llena, la vacía.
  vaciarPapelera.addEventListener("dblclick", vaciar, false);
}; // Fin del window.onload
